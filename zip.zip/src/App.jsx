import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ethers } from 'ethers';

/* ============================================================
   ADITHI — Premium ERC-20 DApp
   ============================================================ */

// ---- Helpers ----
const shortenAddr = (addr) => {
  if (!addr) return '';
  return addr.slice(0, 6) + '…' + addr.slice(-4);
};

const formatADI = (val, decimals = 18) => {
  try {
    return parseFloat(ethers.formatUnits(val, decimals)).toLocaleString(undefined, {
      minimumFractionDigits: 0,
      maximumFractionDigits: 4,
    });
  } catch {
    return '0';
  }
};

const copyToClipboard = async (text) => {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
};

// ---- Config ----
const getConfig = () => {
  const cfg = window.__QUICK_DAPP_CONFIG__ || {};
  const contracts = cfg.contracts || [];
  const primaryId = cfg.primaryContractId;
  const primary = contracts.find((c) => c.id === primaryId) || contracts[0];
  return { cfg, contracts, primary };
};

const EXPLORER_BASES = {
  137: 'https://polygonscan.com',
  80002: 'https://amoy.polygonscan.com',
};

const getExplorerBase = (chainId) => EXPLORER_BASES[chainId] || 'https://polygonscan.com';

// ---- ABI fragment for ERC-20 reads/writes ----
const ERC20_ABI = [
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function decimals() view returns (uint8)',
  'function totalSupply() view returns (uint256)',
  'function balanceOf(address) view returns (uint256)',
  'function transfer(address to, uint256 amount) returns (bool)',
  'function approve(address spender, uint256 amount) returns (bool)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'event Transfer(address indexed from, address indexed to, uint256 value)',
  'event Approval(address indexed owner, address indexed spender, uint256 value)',
];

/* ============================================================
   Particles background
   ============================================================ */
const Particles = () => {
  const particles = React.useMemo(() => {
    return Array.from({ length: 30 }).map((_, i) => ({
      id: i,
      size: Math.random() * 4 + 2,
      top: Math.random() * 100,
      left: Math.random() * 100,
      color: ['#7C3AED', '#3B82F6', '#06B6D4'][Math.floor(Math.random() * 3)],
      duration: Math.random() * 6 + 6,
      delay: Math.random() * 5,
    }));
  }, []);

  return (
    <div className="particles-container">
      {particles.map((p) => (
        <div
          key={p.id}
          className="particle"
          style={{
            width: p.size + 'px',
            height: p.size + 'px',
            top: p.top + '%',
            left: p.left + '%',
            backgroundColor: p.color,
            boxShadow: `0 0 ${p.size * 2}px ${p.color}`,
            animation: `particle ${p.duration}s linear infinite`,
            animationDelay: p.delay + 's',
          }}
        />
      ))}
    </div>
  );
};

/* ============================================================
   Toast notification
   ============================================================ */
const Toast = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 5000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const cls = type === 'success' ? 'toast-success' : type === 'error' ? 'toast-error' : 'toast-info';
  const icon = type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ';

  return (
    <div className={`toast ${cls}`}>
      <span style={{ fontSize: '18px' }}>{icon}</span>
      <span>{message}</span>
    </div>
  );
};

/* ============================================================
   Section wrapper for scroll reveal
   ============================================================ */
const Section = ({ id, children, className = '' }) => {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setVisible(true);
      },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id={id}
      ref={ref}
      className={`section-reveal ${visible ? 'visible' : ''} ${className}`}
    >
      {children}
    </section>
  );
};

/* ============================================================
   3D Coin
   ============================================================ */
const Coin3D = () => (
  <div className="relative flex items-center justify-center" style={{ width: 300, height: 300 }}>
    <div className="coin-ring coin-ring-3" />
    <div className="coin-ring coin-ring-2" />
    <div className="coin-ring coin-ring-1" />
    <div className="coin-3d animate-float-slow">
      <span style={{ fontFamily: "'Space Grotesk', sans-serif" }}>ADI</span>
    </div>
  </div>
);

/* ============================================================
   Main App
   ============================================================ */
export default function App() {
  const { cfg, primary } = getConfig();
  const appTitle = cfg.title || 'ADITHI';

  // ---- State ----
  const [account, setAccount] = useState(null);
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [contract, setContract] = useState(null);
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [networkName, setNetworkName] = useState('');
  const [chainId, setChainId] = useState(null);

  const [tokenInfo, setTokenInfo] = useState({
    name: '—', symbol: '—', decimals: 18, totalSupply: '0',
  });
  const [balance, setBalance] = useState('0');
  const [loadingData, setLoadingData] = useState(false);

  const [sendForm, setSendForm] = useState({ recipient: '', amount: '' });
  const [sendStatus, setSendStatus] = useState(null);
  const [sending, setSending] = useState(false);
  const [gasEstimate, setGasEstimate] = useState(null);

  const [txHistory, setTxHistory] = useState([]);
  const [copied, setCopied] = useState(false);

  const [toast, setToast] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  const showToast = useCallback((message, type = 'info') => {
    setToast({ message, type, id: Date.now() });
  }, []);

  // ---- Contract setup helper ----
  const setupContract = useCallback(async (prov, acct) => {
    if (!primary || !prov) return;
    try {
      const sig = await prov.getSigner();
      const c = new ethers.Contract(primary.address, ERC20_ABI, sig);
      setSigner(sig);
      setContract(c);

      // Read token metadata
      const [name, symbol, decimals, totalSupply] = await Promise.all([
        c.name(), c.symbol(), c.decimals(), c.totalSupply()
      ]);
      setTokenInfo({ name, symbol, decimals: Number(decimals), totalSupply: totalSupply.toString() });

      // Read balance
      if (acct) {
        const bal = await c.balanceOf(acct);
        setBalance(bal.toString());
      }

      // Set network info
      const network = await prov.getNetwork();
      setChainId(Number(network.chainId));
      const chainNames = { 137: 'Polygon Mainnet', 80002: 'Polygon Amoy' };
      setNetworkName(chainNames[Number(network.chainId)] || `Chain ${network.chainId}`);
    } catch (err) {
      console.error('Contract setup error:', err);
    }
  }, [primary]);

  // ---- Connect wallet ----
  const connectWallet = async () => {
    if (connecting) return;
    if (!window.ethereum) {
      showToast('No wallet detected. Please install MetaMask.', 'error');
      return;
    }
    setConnecting(true);
    try {
      const prov = new ethers.BrowserProvider(window.ethereum);
      await prov.send('eth_requestAccounts', []);
      const accounts = await prov.listAccounts();
      const acct = accounts[0]?.address || null;
      setAccount(acct);
      setProvider(prov);
      setConnected(true);
      setLoadingData(true);
      await setupContract(prov, acct);
      setLoadingData(false);
      showToast('Wallet connected successfully!', 'success');
    } catch (err) {
      console.error('Connect error:', err);
      showToast('Failed to connect wallet: ' + (err.message || 'Unknown error'), 'error');
    } finally {
      setConnecting(false);
    }
  };

  // ---- Account / chain change listeners ----
  useEffect(() => {
    if (!window.ethereum) return;

    const handleAccountsChanged = async (accounts) => {
      if (accounts.length === 0) {
        setAccount(null);
        setConnected(false);
        setContract(null);
        setBalance('0');
        showToast('Wallet disconnected.', 'info');
      } else {
        const acct = accounts[0];
        setAccount(acct);
        if (provider) {
          setLoadingData(true);
          await setupContract(provider, acct);
          setLoadingData(false);
        }
      }
    };

    const handleChainChanged = async () => {
      if (provider) {
        setLoadingData(true);
        await setupContract(provider, account);
        setLoadingData(false);
      }
    };

    window.ethereum.on?.('accountsChanged', handleAccountsChanged);
    window.ethereum.on?.('chainChanged', handleChainChanged);

    return () => {
      window.ethereum.removeListener?.('accountsChanged', handleAccountsChanged);
      window.ethereum.removeListener?.('chainChanged', handleChainChanged);
    };
  }, [provider, account, setupContract]);

  // ---- Refresh balance ----
  const refreshBalance = async () => {
    if (!contract || !account) return;
    try {
      const bal = await contract.balanceOf(account);
      setBalance(bal.toString());
      showToast('Balance refreshed.', 'info');
    } catch (err) {
      showToast('Failed to refresh balance.', 'error');
    }
  };

  // ---- Send ADI ----
  const handleSend = async (e) => {
    e?.preventDefault?.();
    if (!contract || !account) {
      showToast('Please connect your wallet first.', 'error');
      return;
    }
    if (!sendForm.recipient || !sendForm.amount) {
      showToast('Please enter recipient address and amount.', 'error');
      return;
    }
    if (!ethers.isAddress(sendForm.recipient)) {
      showToast('Invalid recipient address.', 'error');
      return;
    }
    if (parseFloat(sendForm.amount) <= 0) {
      showToast('Amount must be greater than 0.', 'error');
      return;
    }

    setSending(true);
    setSendStatus('pending');
    const txId = Date.now();
    const txRecord = {
      id: txId,
      hash: '—',
      date: new Date().toLocaleString(),
      type: 'Transfer',
      amount: sendForm.amount,
      status: 'pending',
    };
    setTxHistory((prev) => [txRecord, ...prev]);

    try {
      const decimals = tokenInfo.decimals || 18;
      const amountWei = ethers.parseUnits(sendForm.amount, decimals);
      const tx = await contract.transfer(sendForm.recipient, amountWei);
      txRecord.hash = tx.hash;
      setTxHistory((prev) => prev.map((t) => (t.id === txId ? { ...t, hash: tx.hash } : t)));
      setSendStatus('mining');
      await tx.wait();
      setSendStatus('success');
      setTxHistory((prev) =>
        prev.map((t) => (t.id === txId ? { ...t, status: 'success' } : t))
      );
      showToast(`Successfully sent ${sendForm.amount} ${tokenInfo.symbol}!`, 'success');

      // Refresh balance
      const bal = await contract.balanceOf(account);
      setBalance(bal.toString());

      setSendForm({ recipient: '', amount: '' });
    } catch (err) {
      console.error('Send error:', err);
      setSendStatus('error');
      setTxHistory((prev) =>
        prev.map((t) => (t.id === txId ? { ...t, status: 'failed' } : t))
      );
      const msg = err?.shortMessage || err?.message || 'Transaction failed';
      showToast('Transaction failed: ' + msg, 'error');
    } finally {
      setSending(false);
      setTimeout(() => setSendStatus(null), 3000);
    }
  };

  // ---- Estimate gas for send ----
  const estimateGas = async () => {
    if (!contract || !sendForm.recipient || !sendForm.amount) {
      setGasEstimate(null);
      return;
    }
    if (!ethers.isAddress(sendForm.recipient) || parseFloat(sendForm.amount) <= 0) {
      setGasEstimate(null);
      return;
    }
    try {
      const decimals = tokenInfo.decimals || 18;
      const amountWei = ethers.parseUnits(sendForm.amount, decimals);
      const gas = await contract.transfer.estimateGas(sendForm.recipient, amountWei);
      const prov = contract.runner?.provider || provider;
      if (prov) {
        const feeData = await prov.getFeeData();
        const gasCost = gas * (feeData.gasPrice || 0n);
        setGasEstimate(ethers.formatEther(gasCost));
      }
    } catch {
      setGasEstimate(null);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => estimateGas(), 500);
    return () => clearTimeout(timer);
  }, [sendForm.recipient, sendForm.amount, contract]); // eslint-disable-line react-hooks/exhaustive-deps

  // ---- Copy address ----
  const handleCopy = async () => {
    const ok = await copyToClipboard(primary?.address || '');
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      showToast('Contract address copied!', 'success');
    }
  };

  // ---- Max button ----
  const handleMax = () => {
    const formatted = formatADI(balance, tokenInfo.decimals || 18);
    setSendForm((prev) => ({ ...prev, amount: formatted }));
  };

  // ---- Navigation ----
  const scrollToSection = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setActiveSection(id);
    setMobileMenuOpen(false);
  };

  // ---- Derived values ----
  const displayBalance = formatADI(balance, tokenInfo.decimals || 18);
  const displaySupply = formatADI(tokenInfo.totalSupply, tokenInfo.decimals || 18);
  const explorerBase = getExplorerBase(chainId || primary?.chainId);
  const contractAddr = primary?.address || '';
  const isConnected = connected && account;

  /* ============================================================
     Render
     ============================================================ */
  return (
    <div className="min-h-screen relative">
      <Particles />

      {/* ---- Toast ---- */}
      {toast && <Toast key={toast.id} message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* ============================================================
          NAVBAR
          ============================================================ */}
      <nav className="sticky top-0 z-50 backdrop-blur-xl" style={{
        background: 'rgba(9,11,26,0.8)',
        borderBottom: '1px solid rgba(124,58,237,0.15)',
      }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => scrollToSection('home')}>
              <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm"
                style={{
                  background: 'linear-gradient(135deg, #7C3AED, #3B82F6)',
                  boxShadow: '0 0 15px rgba(124,58,237,0.4)',
                }}>
                ADI
              </div>
              <span className="font-display text-lg font-bold tracking-wider gradient-text">
                {appTitle}
              </span>
            </div>

            {/* Desktop nav */}
            <div className="hidden md:flex items-center gap-8">
              {['home', 'dashboard', 'send', 'transactions', 'about'].map((item) => (
                <a
                  key={item}
                  className="nav-link text-sm font-medium text-white/70 hover:text-white cursor-pointer capitalize"
                  onClick={() => scrollToSection(item)}
                  style={activeSection === item ? { color: '#fff' } : {}}
                >
                  {item === 'send' ? 'Send ADI' : item}
                </a>
              ))}
            </div>

            {/* Connect wallet / Mobile menu toggle */}
            <div className="flex items-center gap-3">
              {isConnected ? (
                <div className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium"
                  style={{
                    background: 'rgba(34,197,94,0.1)',
                    border: '1px solid rgba(34,197,94,0.3)',
                  }}>
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-green-400">{shortenAddr(account)}</span>
                </div>
              ) : (
                <button
                  onClick={connectWallet}
                  disabled={connecting}
                  className="btn-gradient px-5 py-2 rounded-xl text-sm font-semibold text-white"
                >
                  {connecting ? 'Connecting…' : 'Connect Wallet'}
                </button>
              )}
              {/* Mobile menu button */}
              <button
                className="md:hidden p-2 rounded-lg hover:bg-white/5"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  {mobileMenuOpen ? (
                    <path d="M6 18L18 6M6 6l12 12" strokeLinecap="round" strokeLinejoin="round" />
                  ) : (
                    <path d="M4 6h16M4 12h16M4 18h16" strokeLinecap="round" strokeLinejoin="round" />
                  )}
                </svg>
              </button>
            </div>
          </div>

          {/* Mobile menu */}
          <div className={`mobile-menu md:hidden ${mobileMenuOpen ? 'open' : ''}`}>
            <div className="flex flex-col gap-3 py-4">
              {['home', 'dashboard', 'send', 'transactions', 'about'].map((item) => (
                <a
                  key={item}
                  className="text-white/70 hover:text-white py-2 px-4 rounded-lg hover:bg-white/5 cursor-pointer capitalize text-sm font-medium"
                  onClick={() => scrollToSection(item)}
                >
                  {item === 'send' ? 'Send ADI' : item}
                </a>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* ============================================================
          HERO
          ============================================================ */}
      <Section id="home" className="relative z-10 pt-20 pb-32 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="flex-1 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6"
              style={{ background: 'rgba(124,58,237,0.1)', border: '1px solid rgba(124,58,237,0.25)' }}>
              <div className="w-2 h-2 rounded-full bg-adi-violet animate-pulse" />
              <span className="text-xs font-medium text-adi-violet">{tokenInfo.name} ({tokenInfo.symbol}) on Polygon</span>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-4">
              <span className="gradient-text">Welcome to {appTitle}</span>
              <br />
              <span className="text-white">Your Digital Future.</span>
            </h1>
            <p className="text-lg text-white/60 mb-8 max-w-xl mx-auto lg:mx-0">
              Experience seamless crypto transactions on Polygon. Fast, secure, and built for the decentralized economy.
            </p>
            <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
              <button
                onClick={() => scrollToSection('dashboard')}
                className="btn-gradient px-8 py-3.5 rounded-xl font-semibold text-white text-sm"
              >
                Launch Dashboard
              </button>
              <button
                onClick={() => scrollToSection('token-info')}
                className="px-8 py-3.5 rounded-xl font-semibold text-sm transition-all"
                style={{
                  background: 'rgba(17,19,42,0.6)',
                  border: '1px solid rgba(59,130,246,0.3)',
                }}
              >
                <span className="text-blue-400">Explore Token</span>
              </button>
            </div>
          </div>

          {/* 3D Coin */}
          <div className="flex-1 flex justify-center lg:justify-end">
            <Coin3D />
          </div>
        </div>
      </Section>

      {/* ============================================================
          DASHBOARD
          ============================================================ */}
      <Section id="dashboard" className="relative z-10 py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="font-display text-3xl font-bold mb-2">
                <span className="gradient-text">Token Dashboard</span>
              </h2>
              <p className="text-white/50 text-sm">Real-time on-chain data from the {tokenInfo.name} contract</p>
            </div>
            {isConnected && (
              <button
                onClick={refreshBalance}
                className="px-4 py-2 rounded-xl text-xs font-medium text-white/70 hover:text-white transition-all"
                style={{ background: 'rgba(17,19,42,0.6)', border: '1px solid rgba(124,58,237,0.2)' }}
              >
                ↻ Refresh
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* ADI Balance */}
            <div className="glass-card p-6 neon-violet">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-medium text-white/40 uppercase tracking-wider">Your Balance</span>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: 'rgba(124,58,237,0.15)' }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#7C3AED" strokeWidth="2">
                    <path d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              </div>
              <div className="text-3xl font-bold font-display mb-1">
                {loadingData ? '…' : displayBalance}
              </div>
              <div className="text-sm text-white/40">{tokenInfo.symbol || 'ADI'}</div>
            </div>

            {/* Total Supply */}
            <div className="glass-card p-6 neon-blue">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-medium text-white/40 uppercase tracking-wider">Total Supply</span>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: 'rgba(59,130,246,0.15)' }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#3B82F6" strokeWidth="2">
                    <path d="M9 19c-5 0-8-3-8-7s3-7 8-7 8 3 8 7-3 7-8 7z M9 19c3 0 5-3 5-7s-2-7-5-7-5 3-5 7 2 7 5 7z" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              </div>
              <div className="text-3xl font-bold font-display mb-1">
                {loadingData ? '…' : displaySupply}
              </div>
              <div className="text-sm text-white/40">{tokenInfo.symbol || 'ADI'} Tokens</div>
            </div>

            {/* Network Status */}
            <div className="glass-card p-6" style={{ boxShadow: '0 0 20px rgba(6,182,212,0.2)' }}>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-medium text-white/40 uppercase tracking-wider">Network</span>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: 'rgba(6,182,212,0.15)' }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#06B6D4" strokeWidth="2">
                    <path d="M5 12h14m-7-7v14" strokeLinecap="round" strokeLinejoin="round" />
                    <circle cx="12" cy="12" r="9" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              </div>
              <div className="text-xl font-bold font-display mb-1">
                {isConnected ? (networkName || 'Connected') : 'Not Connected'}
              </div>
              <div className="text-sm text-white/40">
                {isConnected ? `Chain ID: ${chainId || '—'}` : 'Connect your wallet'}
              </div>
            </div>

            {/* Contract Address */}
            <div className="glass-card p-6" style={{ boxShadow: '0 0 20px rgba(124,58,237,0.15)' }}>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-medium text-white/40 uppercase tracking-wider">Contract</span>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: 'rgba(124,58,237,0.15)' }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" strokeWidth="2">
                    <path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              </div>
              <div className="text-sm font-mono mb-2 break-all text-white/70">
                {shortenAddr(contractAddr)}
              </div>
              <div className="flex gap-2">
                <button onClick={handleCopy} className="text-xs px-3 py-1.5 rounded-lg transition-all hover:bg-white/5"
                  style={{ background: 'rgba(124,58,237,0.1)', border: '1px solid rgba(124,58,237,0.2)' }}>
                  {copied ? '✓ Copied' : 'Copy'}
                </button>
                <a href={`${explorerBase}/address/${contractAddr}`} target="_blank" rel="noopener noreferrer"
                  className="text-xs px-3 py-1.5 rounded-lg transition-all hover:bg-white/5"
                  style={{ background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.2)' }}>
                  Explorer ↗
                </a>
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* ============================================================
          SEND ADI PANEL
          ============================================================ */}
      <Section id="send" className="relative z-10 py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="font-display text-3xl font-bold mb-2">
              <span className="gradient-text">Send ADI</span>
            </h2>
            <p className="text-white/50 text-sm">Transfer {tokenInfo.symbol} tokens to any address</p>
          </div>

          <div className="glass-card p-8 neon-violet">
            {!isConnected ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl flex items-center justify-center"
                  style={{ background: 'rgba(124,58,237,0.1)' }}>
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#7C3AED" strokeWidth="2">
                    <path d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Connect Your Wallet</h3>
                <p className="text-white/50 text-sm mb-6">Connect your wallet to start sending {tokenInfo.symbol} tokens</p>
                <button onClick={connectWallet} disabled={connecting} className="btn-gradient px-8 py-3 rounded-xl font-semibold text-white text-sm">
                  {connecting ? 'Connecting…' : 'Connect Wallet'}
                </button>
              </div>
            ) : (
              <form onSubmit={handleSend} className="space-y-5">
                {/* Recipient */}
                <div>
                  <label className="block text-xs font-medium text-white/50 uppercase tracking-wider mb-2">
                    Recipient Address
                  </label>
                  <input
                    type="text"
                    placeholder="0x…"
                    value={sendForm.recipient}
                    onChange={(e) => setSendForm({ ...sendForm, recipient: e.target.value })}
                    className="input-adi font-mono"
                  />
                </div>

                {/* Amount */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-xs font-medium text-white/50 uppercase tracking-wider">
                      Amount
                    </label>
                    <button
                      type="button"
                      onClick={handleMax}
                      className="text-xs px-3 py-1 rounded-lg font-bold transition-all hover:scale-105"
                      style={{ background: 'linear-gradient(135deg, rgba(124,58,237,0.2), rgba(59,130,246,0.2))' }}
                    >
                      MAX
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      inputMode="decimal"
                      placeholder="0.0"
                      value={sendForm.amount}
                      onChange={(e) => setSendForm({ ...sendForm, amount: e.target.value })}
                      className="input-adi pr-16"
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-sm font-medium text-white/40">
                      {tokenInfo.symbol}
                    </span>
                  </div>
                </div>

                {/* Info row */}
                <div className="flex items-center justify-between text-xs text-white/50 py-2 px-1">
                  <span>Available: <span className="text-white/80 font-medium">{displayBalance} {tokenInfo.symbol}</span></span>
                  {gasEstimate && (
                    <span>Est. Gas: <span className="text-white/80 font-medium">≈ {parseFloat(gasEstimate).toFixed(6)} ETH</span></span>
                  )}
                </div>

                {/* Status indicator */}
                {sendStatus && (
                  <div className="text-center text-sm py-2 px-4 rounded-xl" style={{
                    background: sendStatus === 'success' ? 'rgba(34,197,94,0.1)' :
                               sendStatus === 'pending' || sendStatus === 'mining' ? 'rgba(234,179,8,0.1)' :
                               'rgba(239,68,68,0.1)',
                  }}>
                    {sendStatus === 'pending' && '⏳ Preparing transaction…'}
                    {sendStatus === 'mining' && '⛏️ Transaction mining…'}
                    {sendStatus === 'success' && '✅ Transaction successful!'}
                    {sendStatus === 'error' && '❌ Transaction failed'}
                  </div>
                )}

                {/* Send button */}
                <button
                  type="submit"
                  disabled={sending || !sendForm.recipient || !sendForm.amount}
                  className="btn-gradient w-full py-4 rounded-xl font-bold text-white text-base"
                >
                  {sending ? 'Processing…' : `Send ${tokenInfo.symbol}`}
                </button>
              </form>
            )}
          </div>
        </div>
      </Section>

      {/* ============================================================
          TRANSACTION HISTORY
          ============================================================ */}
      <Section id="transactions" className="relative z-10 py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h2 className="font-display text-3xl font-bold mb-2">
              <span className="gradient-text">Transaction History</span>
            </h2>
            <p className="text-white/50 text-sm">Your recent {tokenInfo.symbol} transfers</p>
          </div>

          <div className="glass-card overflow-hidden">
            {txHistory.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl flex items-center justify-center"
                  style={{ background: 'rgba(124,58,237,0.1)' }}>
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#7C3AED" strokeWidth="2">
                    <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <p className="text-white/40 text-sm">No transactions yet. Send some {tokenInfo.symbol} to see history here.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr style={{ borderBottom: '1px solid rgba(124,58,237,0.15)' }}>
                      <th className="text-left text-xs font-medium text-white/40 uppercase tracking-wider px-6 py-4">Tx Hash</th>
                      <th className="text-left text-xs font-medium text-white/40 uppercase tracking-wider px-6 py-4">Date</th>
                      <th className="text-left text-xs font-medium text-white/40 uppercase tracking-wider px-6 py-4">Type</th>
                      <th className="text-right text-xs font-medium text-white/40 uppercase tracking-wider px-6 py-4">Amount</th>
                      <th className="text-center text-xs font-medium text-white/40 uppercase tracking-wider px-6 py-4">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {txHistory.map((tx) => (
                      <tr key={tx.id} className="tx-row" style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                        <td className="px-6 py-4">
                          {tx.hash !== '—' ? (
                            <a href={`${explorerBase}/tx/${tx.hash}`} target="_blank" rel="noopener noreferrer"
                              className="text-sm font-mono text-blue-400 hover:text-blue-300 transition-colors">
                              {shortenAddr(tx.hash)} ↗
                            </a>
                          ) : (
                            <span className="text-sm text-white/30 font-mono">Pending…</span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-sm text-white/50">{tx.date}</td>
                        <td className="px-6 py-4 text-sm text-white/70">{tx.type}</td>
                        <td className="px-6 py-4 text-right text-sm font-medium text-white">{tx.amount} {tokenInfo.symbol}</td>
                        <td className="px-6 py-4 text-center">
                          <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                            tx.status === 'success' ? 'badge-success' :
                            tx.status === 'pending' ? 'badge-pending' : 'badge-failed'
                          }`}>
                            {tx.status === 'success' ? 'Success' :
                             tx.status === 'pending' ? 'Pending' : 'Failed'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </Section>

      {/* ============================================================
          TOKEN INFORMATION
          ============================================================ */}
      <Section id="token-info" className="relative z-10 py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="font-display text-3xl font-bold mb-2">
              <span className="gradient-text">Token Information</span>
            </h2>
            <p className="text-white/50 text-sm">Details about the {tokenInfo.name} ({tokenInfo.symbol}) token</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
            {[
              { label: 'Name', value: tokenInfo.name, icon: '📝' },
              { label: 'Symbol', value: tokenInfo.symbol, icon: '🏷️' },
              { label: 'Network', value: 'Polygon PoS', icon: '🔗' },
              { label: 'Standard', value: 'ERC-20', icon: '📋' },
              { label: 'Decimals', value: String(tokenInfo.decimals || 18), icon: '🔢' },
              { label: 'Supply Type', value: 'Fixed', icon: '🔒' },
            ].map((item, idx) => (
              <div key={idx} className="glass-card p-5 text-center">
                <div className="text-2xl mb-3">{item.icon}</div>
                <div className="text-xs text-white/40 uppercase tracking-wider mb-1">{item.label}</div>
                <div className="text-sm font-semibold text-white truncate">{item.value}</div>
              </div>
            ))}
          </div>

          <div className="glass-card p-8 flex flex-col lg:flex-row items-center justify-between gap-6">
            <div className="text-center lg:text-left">
              <h3 className="font-display text-xl font-bold mb-2">Contract Address</h3>
              <p className="text-sm font-mono text-white/60 break-all">{contractAddr}</p>
            </div>
            <div className="flex gap-3 flex-wrap justify-center">
              <button
                onClick={handleCopy}
                className="px-6 py-3 rounded-xl text-sm font-medium transition-all hover:scale-105"
                style={{ background: 'rgba(124,58,237,0.1)', border: '1px solid rgba(124,58,237,0.3)' }}
              >
                {copied ? '✓ Copied!' : 'Copy Address'}
              </button>
              <a
                href={`${explorerBase}/address/${contractAddr}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 rounded-xl text-sm font-medium transition-all hover:scale-105"
                style={{ background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.3)' }}
              >
                View on PolygonScan ↗
              </a>
            </div>
          </div>
        </div>
      </Section>

      {/* ============================================================
          ABOUT SECTION
          ============================================================ */}
      <Section id="about" className="relative z-10 py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl font-bold mb-4">
              <span className="gradient-text">About {appTitle}</span>
            </h2>
            <p className="text-white/50 text-sm max-w-2xl mx-auto">
              {appTitle} is an ERC-20 token built on the Polygon blockchain, offering fast, secure, and low-cost
              transactions for the decentralized future. Our platform empowers users with full control over their
              digital assets through transparent smart-contract technology.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Secure Transfers */}
            <div className="glass-card p-8 text-center neon-violet" style={{ borderRadius: 20 }}>
              <div className="w-16 h-16 mx-auto mb-5 rounded-2xl flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, rgba(124,58,237,0.2), rgba(124,58,237,0.05))' }}>
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" strokeWidth="2">
                  <path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <h3 className="font-display text-lg font-bold mb-3">Secure Transfers</h3>
              <p className="text-white/50 text-sm">
                Every transaction is secured by Polygon's robust proof-of-stake consensus,
                ensuring your tokens are always safe and verifiable on-chain.
              </p>
            </div>

            {/* Polygon Blockchain */}
            <div className="glass-card p-8 text-center neon-blue" style={{ borderRadius: 20 }}>
              <div className="w-16 h-16 mx-auto mb-5 rounded-2xl flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, rgba(59,130,246,0.2), rgba(59,130,246,0.05))' }}>
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" strokeWidth="2">
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <h3 className="font-display text-lg font-bold mb-3">Polygon Blockchain</h3>
              <p className="text-white/50 text-sm">
                Built on Polygon's high-performance Layer 2 network, {appTitle} delivers lightning-fast
                transactions with minimal gas fees and full Ethereum compatibility.
              </p>
            </div>

            {/* Wallet Control */}
            <div className="glass-card p-8 text-center" style={{ borderRadius: 20, boxShadow: '0 0 20px rgba(6,182,212,0.2)' }}>
              <div className="w-16 h-16 mx-auto mb-5 rounded-2xl flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, rgba(6,182,212,0.2), rgba(6,182,212,0.05))' }}>
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#22d3ee" strokeWidth="2">
                  <path d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <h3 className="font-display text-lg font-bold mb-3">Wallet Control</h3>
              <p className="text-white/50 text-sm">
                Your keys, your tokens. {appTitle} uses non-custodial wallet integration,
                meaning you always retain full control of your assets — no intermediaries required.
              </p>
            </div>
          </div>
        </div>
      </Section>

      {/* ============================================================
          FOOTER
          ============================================================ */}
      <footer className="relative z-10 mt-20 py-12 px-4 sm:px-6 lg:px-8" style={{ borderTop: '1px solid rgba(124,58,237,0.1)' }}>
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            {/* Brand */}
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm"
                  style={{
                    background: 'linear-gradient(135deg, #7C3AED, #3B82F6)',
                    boxShadow: '0 0 15px rgba(124,58,237,0.4)',
                  }}>
                  ADI
                </div>
                <span className="font-display text-lg font-bold gradient-text">{appTitle}</span>
              </div>
              <p className="text-white/40 text-sm max-w-md">
                Your Digital Future. A premium ERC-20 token experience on the Polygon blockchain —
                fast, secure, and built for the decentralized economy.
              </p>
            </div>

            {/* Navigation */}
            <div>
              <h4 className="text-sm font-semibold text-white/70 mb-4">Navigation</h4>
              <div className="flex flex-col gap-2">
                {[
                  { label: 'Home', id: 'home' },
                  { label: 'Dashboard', id: 'dashboard' },
                  { label: 'Send ADI', id: 'send' },
                  { label: 'Transactions', id: 'transactions' },
                  { label: 'About', id: 'about' },
                ].map((link) => (
                  <a key={link.id} onClick={() => scrollToSection(link.id)}
                    className="text-sm text-white/40 hover:text-white transition-colors cursor-pointer">
                    {link.label}
                  </a>
                ))}
              </div>
            </div>

            {/* Resources */}
            <div>
              <h4 className="text-sm font-semibold text-white/70 mb-4">Resources</h4>
              <div className="flex flex-col gap-2">
                <a href={`${explorerBase}/address/${contractAddr}`} target="_blank" rel="noopener noreferrer"
                  className="text-sm text-white/40 hover:text-white transition-colors">PolygonScan ↗</a>
                <a href="https://polygon.technology/" target="_blank" rel="noopener noreferrer"
                  className="text-sm text-white/40 hover:text-white transition-colors">Polygon Docs ↗</a>
                <a href="https://ethereum.org/en/developers/docs/standards/tokens/erc-20/" target="_blank" rel="noopener noreferrer"
                  className="text-sm text-white/40 hover:text-white transition-colors">ERC-20 Standard ↗</a>
              </div>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="pt-8" style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}>
            <p className="text-xs text-white/30 text-center max-w-3xl mx-auto">
              ⚠️ Digital assets carry risk. {appTitle} ({tokenInfo.symbol}) is a decentralized token on the Polygon blockchain.
              Always do your own research and never invest more than you can afford to lose. Transactions are irreversible.
              This application is provided "as is" without warranties of any kind.
            </p>
            <p className="text-xs text-white/20 text-center mt-4">
              © {new Date().getFullYear()} {appTitle}. Built on Polygon.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
